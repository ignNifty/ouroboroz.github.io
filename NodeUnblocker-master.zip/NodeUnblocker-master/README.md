# Node Unblocker (Disguised as Google)

An improved version of nodeunblocker.com

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/BinBashBanana/NodeUnblocker)

Usage: `https://example.com/textbooks/https://example.com`

# Running Locally

Setup

`npm install`



Running

`npm start`

Available on `localhost:8080`



All source code is copyright [Nathan Friedly](http://nfriedly.com/).